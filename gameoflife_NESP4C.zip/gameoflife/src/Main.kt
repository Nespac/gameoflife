import javafx.application.Application

fun main(){
    Application.launch(App::class.java)
}